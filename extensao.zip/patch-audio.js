/**
 * patch-audio.js - restaura o sinal sonoro da bipagem (Total Express / ICS)
 *
 * PROBLEMA (medido, nao inferido):
 *   - agentes/caf_reg_do.php linhas 177-190: playTemEncomendas e playUltimaEncomenda
 *     sao declaradas com "var" DENTRO do callback de jN(document).ready(), ficam presas
 *     na closure, e NENHUM ponto do sistema as chama. Verificado nos 71 scripts
 *     carregados + o HTML da pagina: os unicos .play() sao esses dois, orfaos.
 *   - agentes/caf_view.php, onde a bipagem repetida realmente acontece, nao tem
 *     codigo de audio nenhum.
 *   - /audio/som-erro.wav e /audio/som-sucesso.wav respondem 200/206 e tocam
 *     normalmente. O audio nunca foi o problema.
 *
 * COMO ESTE PATCH DECIDE O QUE TOCAR:
 *   ERRO    -> engancha window.alert. Todo caminho de erro da bipagem termina num
 *              alert(): o do AJAX (ajax_validar_rota_awb.php com sucesso:false) e o
 *              que o servidor injeta no topo da resposta do POST de caf_reg_do.php.
 *              Enganchar o alert cobre todos de uma vez, sem mapear caso a caso.
 *   SUCESSO -> compara o contador de encomendas da CAF com o valor guardado em
 *              sessionStorage. Erro nunca incrementa o contador, entao ele so sobe
 *              quando a encomenda entrou de verdade. Sobrevive ao reload de pagina.
 *
 * INSTALACAO: incluir nas DUAS telas, o mais cedo possivel dentro do <head>:
 *     <script src="/js/patch-audio.js"></script>
 *   em agentes/caf_reg_do.php e agentes/caf_view.php.
 *   E apagar o bloco morto de caf_reg_do.php linhas 177-190.
 *
 * VERIFICACAO: abra a tela de bipagem e rode __beepAutoteste() no console.
 */
(function () {
    'use strict';

    // So as telas de bipagem. O manifest da extensao usa um padrao largo de propósito:
    // padrao de URL do Chrome tem pegadinha com query string, e o gancho no alert
    // precisa ser instalado em document_start, quando ainda nao existe DOM para
    // inspecionar. Decidir aqui pelo pathname e mais preciso e mais facil de testar.
    var TELAS = /\/agentes\/(caf_reg_do|caf_view)\.php$/;
    if (!TELAS.test(location.pathname)) return;

    var SONS = { sucesso: '/audio/som-sucesso.wav', erro: '/audio/som-erro.wav' };
    var TOM = { sucesso: 880, erro: 220 };   // Hz do fallback sintetizado
    var PREFIXO = '[beep]';
    var cache = {};
    var ctxAudio = null;

    function log() {
        // A falha original era silenciosa. Aqui nada falha calado.
        try { console.warn.apply(console, [PREFIXO].concat(Array.prototype.slice.call(arguments))); }
        catch (e) {}
    }

    // Fallback: se o .wav sumir do servidor, sintetiza o bip na Web Audio API.
    function oscilador(tipo) {
        try {
            var AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) { log('sem Web Audio API: impossivel emitir som'); return; }
            if (!ctxAudio || ctxAudio.state === 'closed') { ctxAudio = new AC(); }
            if (ctxAudio.state === 'suspended') { ctxAudio.resume(); }
            var osc = ctxAudio.createOscillator();
            var vol = ctxAudio.createGain();
            osc.type = 'square';
            osc.frequency.value = TOM[tipo];
            vol.gain.value = 0.15;
            osc.connect(vol);
            vol.connect(ctxAudio.destination);
            osc.start();
            osc.stop(ctxAudio.currentTime + (tipo === 'erro' ? 0.35 : 0.18));
            log('fallback sintetizado usado para "' + tipo + '"');
        } catch (e) {
            log('fallback do oscilador tambem falhou:', e && e.message);
        }
    }

    function tocar(tipo) {
        var el = cache[tipo];
        if (!el) {
            el = cache[tipo] = new Audio(SONS[tipo]);
            el.preload = 'auto';
            el.addEventListener('error', function () {
                var cod = el.error ? el.error.code : '?';
                log('arquivo ' + SONS[tipo] + ' nao carregou (MediaError ' + cod + ')');
            });
        }
        try { el.currentTime = 0; } catch (e) {}

        var p;
        try {
            p = el.play();
        } catch (e) {
            log('play() lancou excecao:', e && e.message);
            return oscilador(tipo);
        }
        // O codigo original chamava snd.play() sem .catch(): qualquer rejeicao sumia.
        if (p && typeof p.catch === 'function') {
            p.catch(function (e) {
                log('play() REJEITADO (' + e.name + ': ' + e.message + ') para ' + SONS[tipo]);
                if (e.name === 'NotAllowedError') {
                    log('bloqueio de autoplay: o som sai no proximo bipe, ja com gesto do operador');
                }
                oscilador(tipo);
            });
        }
    }

    // Destrava o autoplay no primeiro gesto do operador. Depois do reload de pagina a
    // ativacao do usuario zera e o Chrome pode recusar o play(). Um toque mudo no
    // primeiro keydown/click deixa o elemento liberado para os bipes seguintes.
    function destravar() {
        Object.keys(SONS).forEach(function (tipo) {
            try {
                var el = cache[tipo] || (cache[tipo] = new Audio(SONS[tipo]));
                el.muted = true;
                var p = el.play();
                if (p && p.then) {
                    p.then(function () { el.pause(); el.currentTime = 0; el.muted = false; },
                        function () { el.muted = false; });
                }
            } catch (e) {}
        });
        if (ctxAudio && ctxAudio.state === 'suspended') { ctxAudio.resume(); }
        document.removeEventListener('keydown', destravar, true);
        document.removeEventListener('click', destravar, true);
    }

    // Contador de encomendas da CAF. Sobe so quando a encomenda entrou de verdade.
    function contador() {
        var total = 0, achou = false;
        ['num_enc_i', 'num_enc_r'].forEach(function (id) {          // caf_view.php
            var el = document.getElementById(id);
            if (el) { total += Number(el.value) || 0; achou = true; }
        });
        if (!achou) {                                                // caf_reg_do.php
            var el2 = document.querySelector('input[name="num_encomendas_scan"]');
            if (el2) { total = Number(el2.value) || 0; achou = true; }
        }
        return achou ? total : null;
    }

    function chaveCaf() {
        var el = document.getElementById('cafid') || document.querySelector('input[name="cafid"]');
        return 'beep:contador:' + (el ? el.value : 'sem-caf');
    }

    function conferirSucesso() {
        var atual = contador();
        if (atual === null) {
            log('contador de encomendas nao encontrado nesta tela: sucesso nao detectavel');
            return;
        }
        var chave = chaveCaf();
        var anterior = null;
        try { anterior = sessionStorage.getItem(chave); } catch (e) {}
        try { sessionStorage.setItem(chave, String(atual)); } catch (e) {}

        if (anterior !== null && atual > Number(anterior)) {
            tocar('sucesso');
        }
    }

    // ---- ERRO: todo caminho de erro da bipagem passa por aqui ----
    var alertOriginal = window.alert;
    window.alert = function (msg) {
        try { tocar('erro'); } catch (e) { log('falha ao tocar erro:', e && e.message); }
        return alertOriginal.apply(window, arguments);
    };

    // ---- ligacao ----
    document.addEventListener('keydown', destravar, true);
    document.addEventListener('click', destravar, true);
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', conferirSucesso);
    } else {
        conferirSucesso();
    }

    // Autoteste manual: rode __beepAutoteste() no console da tela de bipagem.
    window.__beepAutoteste = function () {
        var r = {
            contador: contador(),
            chave: chaveCaf(),
            alertEnganchado: window.alert !== alertOriginal
        };
        console.log(PREFIXO, 'estado:', r);
        console.log(PREFIXO, 'tocando sucesso...');
        tocar('sucesso');
        setTimeout(function () { console.log(PREFIXO, 'tocando erro...'); tocar('erro'); }, 1200);
        setTimeout(function () {
            console.log(PREFIXO, 'testando fallback sintetizado (ignora o .wav)...');
            oscilador('erro');
        }, 2400);
        return r;
    };
})();
