# Instalação — sinal sonoro da bipagem

Extensão que devolve o bip de sucesso e de erro na tela de bipagem do ICS.
Roda só no navegador do operador. **Não altera nada no servidor da Total Express.**

Leva menos de dois minutos por máquina.

## Instalar

1. Crie a pasta `C:\ICS` e **extraia o arquivo `extensao-som-ics-1.0.0.zip` dentro dela**.
   Clique com o botão direito no arquivo, **Extrair tudo**, e aponte para `C:\ICS`.

   O lugar precisa ser **fixo**, onde ninguém vá apagar: se a pasta for movida ou apagada
   depois, a extensão para de funcionar.

2. Abra a pasta que saiu da extração e confirme que o arquivo **`manifest.json` está ali
   dentro**, solto. É essa pasta que o Chrome vai pedir no passo 5 — apontar para a pasta
   de cima é o erro mais comum, e o Chrome recusa com "Manifest file is missing".

3. Abra o Chrome e vá em `chrome://extensions` (dá para colar isso na barra de endereço).

4. Ligue o **Modo do desenvolvedor**, no canto superior direito.

5. Clique em **Carregar sem compactação** e escolha a pasta do passo 2.

6. Confirme que apareceu o cartão **"ICS Bipagem - sinal sonoro"** e que ele está **ativado**.

Pronto. Não precisa reiniciar o Chrome nem fazer login de novo.

## Conferir se funcionou

1. Abra a tela de bipagem do ICS normalmente.
2. Bipe uma AWB que você sabe que dá erro.
3. Deve sair o som de erro junto com a mensagem na tela.

Se quiser testar sem bipar nada: com a tela de bipagem aberta, aperte `F12`, vá na aba
**Console**, digite `__beepAutoteste()` e dê Enter. Ele toca o som de sucesso, depois o de
erro, depois o bip sintetizado de reserva.

## Se não funcionar

| Sintoma | O que verificar |
|---|---|
| Nenhum som em lugar nenhum | O volume do computador e da aba do Chrome. Clique com o botão direito na aba: ela não pode estar em "Silenciar site". |
| Toca no teste do console mas não no bipe | Confirme que a URL é `caf_reg_do.php` ou `caf_view.php`. A extensão só age nessas duas telas, de propósito. |
| Cartão da extensão com erro | A pasta foi movida ou apagada. Refaça a instalação apontando para o novo lugar. |
| Sumiu depois de atualizar o Chrome | O Modo do desenvolvedor foi desligado. Ligue de novo em `chrome://extensions`. |

Para diagnóstico, o `F12` na aba **Console** mostra tudo que a extensão faz. Toda falha é
registrada com o prefixo `[beep]`. Se o `.wav` sumir do servidor, ela cai sozinha num bip
sintetizado e avisa no console — não fica muda.

## Atualizar

Substitua os arquivos da pasta e clique no ícone de recarregar no cartão da extensão,
em `chrome://extensions`.

## Observações para o TI

- Manifest V3, sem permissões declaradas e sem acesso à rede. Só um content script nas duas
  telas de bipagem.
- Roda em `world: MAIN` porque o gancho no `alert()` da página não funciona em contexto
  isolado, que é o padrão das extensões.
- Não lê, não guarda e não envia dado nenhum. O único estado é um contador no
  `sessionStorage` da própria aba, que serve para saber se a encomenda entrou.
- O "Modo do desenvolvedor" é exigido porque a extensão não está publicada na Chrome Web
  Store. Para uma frota grande, o caminho melhor é empacotar e distribuir por política de
  grupo (`ExtensionInstallForcelist`), o que também elimina o aviso de modo desenvolvedor.
- Isso é um paliativo de navegador. A correção definitiva é a Total Express incluir o
  `patch-audio.js` em `agentes/caf_reg_do.php` e `agentes/caf_view.php`, e apagar o bloco
  morto das linhas 177-190 do `caf_reg_do.php`.
